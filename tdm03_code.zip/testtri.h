/* testtri.h (IGI-3005)

  JCG 15/09/2008
  maj 07/12/2017
  DV  2024-11-22
  
  fonction de test et de chronométrage de différents tris 
*/

int testtri();
